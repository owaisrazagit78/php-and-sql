<?php
$con = mysqli_connect("localhost", "root", "", "addtocart");
session_start();
// session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
<ul class="nav justify-content-end p-4">
    <?php
    $count = 0;
    if (isset($_SESSION['cart'])) {
        $count = count($_SESSION['cart']);
    }
    ?>
    <li><a href="cart.php" class="btn btn-primary">Cart (<?php echo $count; ?>)</a></li>
</ul>
<div class="row m-4">
    <?php
    $query = "SELECT * FROM cart";
    $res = mysqli_query($con, $query);
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            echo "
            <div class='col col-4'>
                <form method='POST'>
                    <div class='card' style='width: 18rem;'>
                        <div class='card-body'>
                            <h5 class='card-title'>" . ($row['name']) . "</h5>
                            <p class='card-text'>" . ($row['price']) . "</p>
                            <p class='card-text'>" . ($row['brand']) . "</p>
                            <button type='submit' name='add' class='btn btn-primary'>Add to Cart</button>
                            <input type='hidden' value='" . ($row['name']) . "' name='name'>
                            <input type='hidden' value='" . ($row['price']) . "' name='price'>
                            <input type='hidden' value='" . ($row['brand']) . "' name='brand'>
                            </div>
                    </div>
                </form>
            </div>";
        }
    }
    ?>
</div>
</body>
</html>

<?php
if (isset($_POST['add'])) {

    if (isset($_SESSION['cart'])) {

        $array_item = array_column($_SESSION['cart'], 'name');

        if (in_array($_POST['name'], $array_item)) {
            echo "<script>alert('Item already exists in cart');</script>";

        } else {
            $count = count($_SESSION['cart']);
            $_SESSION['cart'][$count] = array('name' => $_POST['name'], 'price' => $_POST['price'],'brand' => $_POST['brand'] ,'quantity' => 1);
            echo "<script> window.location.href = 'index.php'; </script>";
        }

    } 
    
    else {
        
        $_SESSION['cart'][0] = array('name' => $_POST['name'], 'price' => $_POST['price'],'brand' => $_POST['brand'], 'quantity' => 1);
       header("location:index.php");

    }
   
}
?>
