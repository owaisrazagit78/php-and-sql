<?php
session_start();

// Handle removal of item
if (isset($_POST['remove_item'])) {
    $Id = $_POST['remove_item'];
    unset($_SESSION['cart'][$Id]);
    $_SESSION['cart'] = array_values($_SESSION['cart']);
    header("Location: cart.php");
    exit();
}

// // Handle continue to shop button
if (isset($_POST['shop'])) {
    header("Location: index.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Cart</title>
    <script>
        function updateTotalPrice(input) {
            var row = input.closest('tr');
            var price = parseFloat(row.querySelector('.price').textContent);
            var quantity = parseInt(input.value);
            var totalPrice = price * quantity;
            row.querySelector('.total').textContent = totalPrice.toFixed(2);
            updateGrandTotal();
        }

        function updateGrandTotal() {
            var totalCells = document.querySelectorAll('.total');
            var grandTotal = 0;
            totalCells.forEach(function(cell) {
                grandTotal += parseFloat(cell.textContent) || 0;
            });
            document.getElementById('grand-total').textContent = grandTotal.toFixed(2);
        }

        window.onload = updateGrandTotal;
    </script>
</head>
<body>
  <table class="table table-dark">
   <thead>
       <tr>
          <th scope="col">Name</th>
          <th scope="col">Price</th>
          <th scope="col">Brand</th>
          <th scope="col">Quantity</th>
          <th scope="col">Total</th>
          <th scope="col">Operation</th>
       </tr>
  </thead>
  
  <tbody>
    <?php
       $grandTotal = 0;
       if (isset($_SESSION['cart'])) {
          
           foreach ($_SESSION['cart'] as $key => $value) {
               $totalPrice = $value['price'] * $value['quantity'];
               $grandTotal += $totalPrice; 

               echo "
               <tr>
                 <th>{$value['name']}</th>
                 <td class='price'>{$value['price']}</td>
                 <td>{$value['brand']}</td>
                 <td>
                   <form method='POST'>
                     <input type='number' name='Mod_Quantity' min='1' value='{$value['quantity']}' class='quant' onchange='updateTotalPrice(this)'>
                   </form>
                 </td>
                 <td class='total'>{$totalPrice}</td>
                 <td>
                   <form method='post' style='display:inline;'>
                     <input type='hidden' name='remove_item' value='{$key}'>
                     <button type='submit' class='btn btn-outline-danger'>Remove</button>
                   </form>
                 </td>
               </tr>";
           }
       }
       print_r($_SESSION['cart'])
    ?>
  
    <tr>
                          <!-- //  <input type='hidden' name='item_id' value='{$key}'> -->

        <td colspan="4"><strong>Total Price:</strong></td>
        <td id="grand-total"><?php echo number_format($grandTotal, 2); ?></td>
        <td></td>
    </tr>
    <tr>
        <td colspan="6">
            <button class="btn btn-primary">Checkout</button>
               <form method="post" style="display:inline;">
                   <button type="submit" class="btn btn-secondary" name="shop">Continue To Shop</button>
                </form>
        </td>
    </tr>

  </tbody>

</table>
</body>
</html>
